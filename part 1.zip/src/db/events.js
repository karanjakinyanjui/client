class events {
  constructor() {
    this.events = [
      {
        name: "First Event",
        topic: "Math",
        price: 600,
        location: "here",
        time: "now",
        duration: "2 hrs",
      },
    ];
  }

  addEvent(event) {
    this.events.push(event);
  }

  editEvent(eventID, update) {
    let event = this.events.find((e) => e._id == eventID);

    Object.assign(event, update);
  }

  deleteEvent(eventID) {
    this.events = this.events.filter((e) => e._id != eventID);
  }

  getEvents() {
    return this.events;
  }
}
